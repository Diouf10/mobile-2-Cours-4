package cstjean.mobile.cours3.travail

import java.util.*

data class Travail(val id: UUID, val nom: String, val dateRemise: Date, val estTermine: Boolean)
