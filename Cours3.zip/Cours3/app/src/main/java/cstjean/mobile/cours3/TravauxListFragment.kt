package cstjean.mobile.cours3

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import cstjean.mobile.cours3.databinding.FragmentTravauxListBinding
import cstjean.mobile.cours3.travail.TravauxListAdapter

private const val TAG = "TravauxListFragment"

class TravauxListFragment : Fragment() {
    private var _binding: FragmentTravauxListBinding? = null
    private val binding
        get() = checkNotNull(_binding) {
            "Binding est null. La vue est visible ??"
        }

    private val travauxListViewModel: TravauxListViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "Travaux : ${travauxListViewModel.travaux.size}")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTravauxListBinding.inflate(inflater, container, false)
        binding.travauxRecyclerView.layoutManager = LinearLayoutManager(context)

        val travaux = travauxListViewModel.travaux
        val adapter = TravauxListAdapter(travaux)
        binding.travauxRecyclerView.adapter = adapter


        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
