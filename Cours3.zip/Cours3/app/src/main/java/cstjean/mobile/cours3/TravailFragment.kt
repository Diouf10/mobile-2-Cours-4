package cstjean.mobile.cours3

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import androidx.core.widget.doOnTextChanged
import cstjean.mobile.cours3.databinding.FragmentTravailBinding
import cstjean.mobile.cours3.travail.Travail
import java.util.*

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

class TravailFragment : Fragment() {
    private lateinit var travail : Travail
    private lateinit var nomField : EditText
    private var _binding: FragmentTravailBinding? = null
    private val binding: FragmentTravailBinding
        get() = checkNotNull(_binding) {
            "Binding est null, la vue est-elle visible ?"
        }

     override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

         travail = Travail(UUID.randomUUID(), "Travail 1", Date(), false)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       // val view = inflater.inflate(R.layout.fragment_travail, container, false)
       // nomField = view.findViewById(R.id.travail_nom)
        // return view;
        _binding = FragmentTravailBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            travailNom.doOnTextChanged { text, _, _, _ ->
                travail = travail.copy(nom = text.toString())
            }

            travailTermine.setOnCheckedChangeListener { _, isChecked ->
                travail = travail.copy(estTermine = isChecked)
            }

            travailDate.apply {
                text = travail.dateRemise.toString()
                isEnabled = false
            }

        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}

