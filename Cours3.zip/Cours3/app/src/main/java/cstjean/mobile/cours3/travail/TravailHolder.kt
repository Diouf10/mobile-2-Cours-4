package cstjean.mobile.cours3.travail

import android.graphics.drawable.Drawable
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import cstjean.mobile.cours3.R
import cstjean.mobile.cours3.databinding.ListItemTravailBinding

class TravailHolder(val binding: ListItemTravailBinding) :
    RecyclerView.ViewHolder(binding.root) {

    fun bind(travail: Travail) {
        binding.travailNom.text = travail.nom
        binding.travailDate.text = travail.dateRemise.toString()


        binding.root.setOnClickListener {
            Toast.makeText(binding.root.context, travail.nom, Toast.LENGTH_SHORT)
                .show()
        }

    }

}
