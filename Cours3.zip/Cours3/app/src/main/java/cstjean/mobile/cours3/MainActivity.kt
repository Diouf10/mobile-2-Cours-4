package cstjean.mobile.cours3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

/**
 * initialisation de l'Activity
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}