package cstjean.mobile.cours3.travail

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import cstjean.mobile.cours3.databinding.ListItemTravailBinding

class TravauxListAdapter(private val travaux: List<Travail>) :
    RecyclerView.Adapter<TravailHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TravailHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ListItemTravailBinding.inflate(inflater, parent, false)
        return TravailHolder(binding)
    }

    override fun onBindViewHolder(holder: TravailHolder, position: Int) {
        val travail = travaux[position]
        holder.bind(travail)

    }

    override fun getItemCount() = travaux.size


}