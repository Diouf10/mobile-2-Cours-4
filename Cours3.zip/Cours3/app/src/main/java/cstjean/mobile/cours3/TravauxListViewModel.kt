package cstjean.mobile.cours3

import androidx.lifecycle.ViewModel
import cstjean.mobile.cours3.travail.Travail
import java.util.*

class TravauxListViewModel : ViewModel() {
    val travaux = mutableListOf<Travail>()
    init {
        // Données de tests
        for (i in 0 until 100) {
            travaux += Travail(
                UUID.randomUUID(),
                "Travail #$i",
                Date(),
                i % 2 == 0
            )
        }
    }
}
